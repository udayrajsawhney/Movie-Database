import json
import random

def main1():
    file = open("o.txt", "r")
    a = file.readline()
    i=1
    while a!= "":
        
        try:
            data = json.loads(a)
        except:
            break

        print(i, data["name"], data["synopsis"], data["rating"]["imdb"], data["year"], random.randrange(60, 180), random.randrange(5000000, 500000000), data["cover"],data["download"]["links"]["url"],sep='@')
        
        a = file.readline()
        i+=1

def main2():
    file = open("o.txt", "r")
    a = file.readline()
    i=1
    li = []
    dir_set = set()
    while a!= "":
        
        try:
            data = json.loads(a)
        except:
            break

        li2 = data["directors"]
        for each in li2:
            #print(each)
            #dir_set.add(each["name"])
            dir_set.add("@".join([each["name"], each["url"]]))

        a = file.readline()
        i+=1

    j=1
    for al in sorted(dir_set):
        print(j,al,sep='@')
        j+=1


def main3():
    file = open("o.txt", "r")
    a = file.readline()
    i=1
    genre_set = set()
    while a!= "":
        
        try:
            data = json.loads(a)
        except:
            break

        for e in data["genres"]:
            genre_set.add(e)
        
        
        a = file.readline()
        i+=1

    k = 1
    for j in genre_set:
        print(k, j, sep=' ')
        k+=1


def main4():
    file = open("o.txt", "r")
    a = file.readline()
    i=1
    actors = set()
    while a!= "":
        
        try:
            data = json.loads(a)
        except:
            break

        for e in data["actors"]:
            actors.add("@".join([e["name"]["original"], e["url"]]))
        
        
        a = file.readline()
        i+=1
    
    k = 1
    for j in sorted(actors):
        print(k,j,sep='@')
        k+=1



if __name__ == "__main__":

     main1()
    # main3()


    #  main2()
    # main4()
    
    


