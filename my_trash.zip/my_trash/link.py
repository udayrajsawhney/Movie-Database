def link_act():

    nli = open("dir_o2.txt", "r").readlines()
    dli = open("dir_det.txt", "r").readlines()

    for i in range(0, len(nli)+5):
        try:
            flag = dli[i][:6]
        except:
            break
         
        if(flag == 'error-'):
            
            dob = "1960-8-26"
            add = "San Francisco, U.S.A."
            act = "http://st1.bgr.in/wp-content/uploads/2015/11/anonymous-hackers-stock-image.jpg"
            li = nli[i]
            li = li.split('@')[:-1]
            li = '@'.join(li)
            print(li, dob, add, act, sep='@')

        elif(flag == '@https'):
            dob = "1960-8-26"
            add = "San Francisco, U.S.A."
            act = "http://st1.bgr.in/wp-content/uploads/2015/11/anonymous-hackers-stock-image.jpg"
            li = nli[i]
            li = li.split('@')[:-1]
            li = '@'.join(li)
            print(li, dob, add, act, sep='@')
        else:
            t1 = nli[i].split('@')[:-1]
            t2 = dli[i].split('@', 2)
            t2[2] = t2[2][:-1]
            t3 = t1+t2
            print("@".join(t3))

if __name__=="__main__":
    link_act()